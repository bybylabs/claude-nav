// Claude 对话导航 v2.0 — Content Script

(function () {
  'use strict';

  let timelinePanel = null;
  let toggleButton = null;
  let isVisible = false;
  let observer = null;
  let updateTimer = null;
  let allHumanMessages = [];
  let userScrollingPanel = false;
  let scrollUnlockTimer = null;

  // ── Share state ────────────────────────────────────────────────────────────
  let shareMode = false;           // whether checkboxes are shown
  let selectedTurns = new Set();   // indices of selected conversation turns (each turn = question + answer)
  let shareToolbar = null;

  // ── Init ──────────────────────────────────────────────────────────────────
  function init() {
    if (document.getElementById('claude-timeline-panel')) return;
    createToggleButton();
    createTimelinePanel();
    observeConversation();
    updateTimeline();
  }

  // ── Toggle Button ─────────────────────────────────────────────────────────
  function createToggleButton() {
    toggleButton = document.createElement('button');
    toggleButton.id = 'claude-timeline-toggle';
    toggleButton.title = '对话导航';
    toggleButton.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/>
        <line x1="3" y1="12" x2="15" y2="12"/>
        <line x1="3" y1="18" x2="18" y2="18"/>
        <circle cx="21" cy="12" r="2" fill="currentColor" stroke="none"/>
        <circle cx="18" cy="18" r="2" fill="currentColor" stroke="none"/>
        <circle cx="21" cy="6" r="2" fill="currentColor" stroke="none"/>
      </svg>
    `;
    toggleButton.addEventListener('click', togglePanel);
    document.body.appendChild(toggleButton);
  }

  // ── Panel ─────────────────────────────────────────────────────────────────
  function createTimelinePanel() {
    timelinePanel = document.createElement('div');
    timelinePanel.id = 'claude-timeline-panel';
    timelinePanel.innerHTML = `
      <div class="tl-header">
        <div class="tl-header-left">
          <span class="tl-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
          </span>
          <span class="tl-title">对话导航</span>
        </div>
        <div class="tl-header-right">
          <span class="tl-count" id="tl-count">0 条</span>
          <button class="tl-icon-btn" id="tl-share-toggle" title="选择分享">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
              <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
              <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
            </svg>
          </button>
          <button class="tl-icon-btn" id="tl-settings" title="设置">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
          </button>
          <button class="tl-close" id="tl-close" title="关闭">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>
      <div class="tl-search-wrap">
        <svg class="tl-search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input class="tl-search" id="tl-search" type="text" placeholder="搜索提问内容…" />
        <button class="tl-search-clear" id="tl-search-clear" title="清除">×</button>
      </div>
      <div class="tl-list" id="tl-list">
        <div class="tl-empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <p>暂无提问内容</p>
        </div>
      </div>
      <div class="tl-footer">
        <button class="tl-refresh" id="tl-refresh" title="刷新">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="23 4 23 10 17 10"/>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
          </svg>
          刷新
        </button>
        <span class="tl-footer-tip" id="tl-footer-tip">点击条目跳转到对应提问</span>
      </div>
    `;
    document.body.appendChild(timelinePanel);

    // Scroll lock
    const list = timelinePanel.querySelector('#tl-list');
    const lockScroll = () => {
      userScrollingPanel = true;
      clearTimeout(scrollUnlockTimer);
      scrollUnlockTimer = setTimeout(() => { userScrollingPanel = false; }, 1500);
    };
    list.addEventListener('wheel', lockScroll, { passive: true });
    list.addEventListener('touchstart', lockScroll, { passive: true });
    list.addEventListener('touchmove', lockScroll, { passive: true });
    list.addEventListener('mousedown', lockScroll);
    document.addEventListener('mouseup', () => {
      if (userScrollingPanel) {
        clearTimeout(scrollUnlockTimer);
        scrollUnlockTimer = setTimeout(() => { userScrollingPanel = false; }, 1500);
      }
    });

    document.getElementById('tl-close').addEventListener('click', togglePanel);
    document.getElementById('tl-refresh').addEventListener('click', updateTimeline);
    document.getElementById('tl-share-toggle').addEventListener('click', toggleShareMode);
    document.getElementById('tl-settings').addEventListener('click', toggleSettingsDrawer);

    const searchInput = document.getElementById('tl-search');
    const searchClear = document.getElementById('tl-search-clear');
    searchInput.addEventListener('input', () => {
      searchClear.style.display = searchInput.value ? 'flex' : 'none';
      applySearch();
    });
    searchClear.addEventListener('click', () => {
      searchInput.value = '';
      searchClear.style.display = 'none';
      applySearch();
    });
  }

  // ── Settings drawer ───────────────────────────────────────────────────────
  let settingsOpen = false;

  function toggleSettingsDrawer() {
    settingsOpen ? closeSettingsDrawer() : openSettingsDrawer();
  }

  function openSettingsDrawer() {
    if (document.getElementById('tl-settings-drawer')) return;
    settingsOpen = true;
    document.getElementById('tl-settings').classList.add('active');

    // Load saved values
    chrome.storage.sync.get(['workerUrl', 'authToken'], data => {
      const drawer = document.createElement('div');
      drawer.id = 'tl-settings-drawer';
      drawer.innerHTML = `
        <div class="tl-drawer-header">
          <span>分享设置</span>
          <button class="tl-icon-btn" id="tl-drawer-close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
        <div class="tl-drawer-body">
          <div class="tl-field">
            <label>Worker 地址</label>
            <input id="tl-worker-url" type="url" placeholder="https://your-worker.workers.dev" value="${data.workerUrl || ''}" />
          </div>
          <div class="tl-field">
            <label>访问密钥 (Token)</label>
            <input id="tl-auth-token" type="password" placeholder="你在 Worker 代码里设置的密钥" value="${data.authToken || ''}" />
          </div>
          <div class="tl-drawer-btns">
            <button id="tl-save-settings">保存</button>
            <button id="tl-test-settings">测试连接</button>
          </div>
          <div class="tl-drawer-status" id="tl-drawer-status"></div>
        </div>
      `;
      timelinePanel.appendChild(drawer);

      document.getElementById('tl-drawer-close').addEventListener('click', closeSettingsDrawer);

      document.getElementById('tl-save-settings').addEventListener('click', () => {
        const url = document.getElementById('tl-worker-url').value.trim().replace(/\/$/, '');
        const token = document.getElementById('tl-auth-token').value.trim();
        if (!url || !token) { showDrawerStatus('请填写 Worker 地址和密钥', 'err'); return; }
        chrome.storage.sync.set({ workerUrl: url, authToken: token }, () => {
          showDrawerStatus('设置已保存 ✓', 'ok');
        });
      });

      document.getElementById('tl-test-settings').addEventListener('click', async () => {
        const url = document.getElementById('tl-worker-url').value.trim().replace(/\/$/, '');
        const token = document.getElementById('tl-auth-token').value.trim();
        if (!url || !token) { showDrawerStatus('请先填写设置', 'err'); return; }
        showDrawerStatus('正在测试…', 'info');
        try {
          const res = await fetch(`${url}/save`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Auth-Token': token },
            body: JSON.stringify({ html: '<p>test</p>', title: '连接测试', ttl: 60 })
          });
          const d = await res.json();
          if (d.url) showDrawerStatus('连接成功 ✓', 'ok');
          else showDrawerStatus(`失败：${d.error || '未知错误'}`, 'err');
        } catch (e) {
          showDrawerStatus(`连接失败：${e.message}`, 'err');
        }
      });
    });
  }

  function closeSettingsDrawer() {
    const drawer = document.getElementById('tl-settings-drawer');
    if (drawer) drawer.remove();
    settingsOpen = false;
    document.getElementById('tl-settings').classList.remove('active');
  }

  function showDrawerStatus(msg, type) {
    const el = document.getElementById('tl-drawer-status');
    if (!el) return;
    el.textContent = msg;
    el.className = 'tl-drawer-status tl-drawer-status-' + type;
  }

    // ── Toggle ────────────────────────────────────────────────────────────────
  function togglePanel() {
    isVisible = !isVisible;
    timelinePanel.classList.toggle('visible', isVisible);
    toggleButton.classList.toggle('active', isVisible);
    if (isVisible) {
      updateTimeline();
      setTimeout(highlightCurrent, 100);
    } else {
      if (shareMode) exitShareMode();
    }
  }

  function highlightCurrent() {
    if (!allHumanMessages.length) return;
    const mid = window.innerHeight / 2;
    let closest = null, closestDist = Infinity;
    allHumanMessages.forEach(msg => {
      if (!msg.el) return;
      const rect = msg.el.getBoundingClientRect();
      const dist = Math.abs(rect.top + rect.height / 2 - mid);
      if (dist < closestDist) { closestDist = dist; closest = msg.index; }
    });
    if (closest !== null) {
      document.querySelectorAll('.tl-item').forEach(el => {
        el.classList.toggle('tl-active', parseInt(el.dataset.origIndex) === closest);
      });
      const active = document.querySelector('.tl-item.tl-active');
      if (active) active.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  }

  // ── Share mode ─────────────────────────────────────────────────────────────
  function toggleShareMode() {
    shareMode ? exitShareMode() : enterShareMode();
  }

  function enterShareMode() {
    shareMode = true;
    selectedTurns.clear();
    document.getElementById('tl-share-toggle').classList.add('active');
    document.getElementById('tl-footer-tip').textContent = '勾选要分享的对话轮次';
    renderItems(allHumanMessages); // re-render with checkboxes
    createShareToolbar();
  }

  function exitShareMode() {
    shareMode = false;
    selectedTurns.clear();
    document.getElementById('tl-share-toggle').classList.remove('active');
    document.getElementById('tl-footer-tip').textContent = '点击条目跳转到对应提问';
    renderItems(allHumanMessages); // re-render without checkboxes
    removeShareToolbar();
  }

  function createShareToolbar() {
    removeShareToolbar();
    shareToolbar = document.createElement('div');
    shareToolbar.id = 'tl-share-toolbar';
    shareToolbar.innerHTML = `
      <div class="tl-share-info">
        <span id="tl-selected-count">已选 0 轮</span>
        <button class="tl-select-all" id="tl-select-all">全选</button>
      </div>
      <div class="tl-share-row">
        <select id="tl-ttl-select" class="tl-ttl-select">
          <option value="86400">24 小时后失效</option>
          <option value="259200">3 天后失效</option>
          <option value="604800" selected>7 天后失效</option>
          <option value="2592000">30 天后失效</option>
          <option value="0">永久有效</option>
        </select>
        <button class="tl-share-btn" id="tl-share-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13">
            <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
            <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
            <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
          </svg>
          生成链接
        </button>
      </div>
      <div class="tl-share-status" id="tl-share-status"></div>
    `;
    timelinePanel.querySelector('.tl-footer').before(shareToolbar);

    document.getElementById('tl-share-btn').addEventListener('click', generateShareLink);
    document.getElementById('tl-select-all').addEventListener('click', () => {
      const allSelected = selectedTurns.size === allHumanMessages.length;
      if (allSelected) {
        selectedTurns.clear();
      } else {
        allHumanMessages.forEach(m => selectedTurns.add(m.index));
      }
      renderItems(allHumanMessages);
      updateSelectedCount();
    });
  }

  function removeShareToolbar() {
    const t = document.getElementById('tl-share-toolbar');
    if (t) t.remove();
    shareToolbar = null;
  }

  function updateSelectedCount() {
    const el = document.getElementById('tl-selected-count');
    if (el) el.textContent = `已选 ${selectedTurns.size} 轮`;
    const allBtn = document.getElementById('tl-select-all');
    if (allBtn) allBtn.textContent = selectedTurns.size === allHumanMessages.length ? '取消全选' : '全选';
  }

  // ── Generate share link ────────────────────────────────────────────────────
  async function generateShareLink() {
    const statusEl = document.getElementById('tl-share-status');

    if (selectedTurns.size === 0) {
      showShareStatus('请先勾选要分享的对话轮次', 'err');
      return;
    }

    const settings = await new Promise(res => chrome.storage.sync.get(['workerUrl', 'authToken'], res));
    if (!settings.workerUrl || !settings.authToken) {
      showShareStatus('请先在设置页面填写 Worker 地址和密钥', 'err');
      // open settings after short delay
      setTimeout(() => openSettingsDrawer(), 1500);
      return;
    }

    showShareStatus('正在生成链接…', 'info');

    // Build HTML from selected turns
    const ttl = parseInt(document.getElementById('tl-ttl-select').value);
    const html = buildShareHtml();
    const title = buildShareTitle();

    try {
      const res = await fetch(`${settings.workerUrl}/save`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Auth-Token': settings.authToken,
        },
        body: JSON.stringify({ html, title, ttl }),
      });
      const data = await res.json();
      if (data.url) {
        await navigator.clipboard.writeText(data.url);
        showShareStatus(`链接已复制到剪贴板 ✓\n${data.url}`, 'ok');
      } else {
        showShareStatus(`生成失败：${data.error || '未知错误'}`, 'err');
      }
    } catch (e) {
      showShareStatus(`请求失败：${e.message}`, 'err');
    }
  }

  function showShareStatus(msg, type) {
    const el = document.getElementById('tl-share-status');
    if (!el) return;
    el.textContent = msg;
    el.className = 'tl-share-status tl-share-status-' + type;
  }

  // Build HTML snippets for selected turns
  function buildShareHtml() {
    const sorted = [...selectedTurns].sort((a, b) => a - b);
    const parts = [];
    sorted.forEach(idx => {
      const msg = allHumanMessages.find(m => m.index === idx);
      if (!msg || !msg.el) return;
      // User question — preserve line breaks
      const questionHtml = escapeHtml(msg.text).replace(/\n/g, '<br>');
      parts.push(`<div class="user-turn"><div class="user-bubble">${questionHtml}</div></div>`);
      // AI answer
      const aiHtml = extractAiAnswer(msg.el);
      if (aiHtml) {
        parts.push(`<div class="ai-turn"><div class="ai-label">Claude</div><div class="ai-body">${aiHtml}</div></div>`);
      }
    });
    return parts.join('\n');
  }

  function buildShareTitle() {
    const sorted = [...selectedTurns].sort((a, b) => a - b);
    if (!sorted.length) return 'Claude 对话摘录';
    const first = allHumanMessages.find(m => m.index === sorted[0]);
    if (!first) return 'Claude 对话摘录';
    return first.text.slice(0, 40) + (first.text.length > 40 ? '…' : '');
  }

  // Find and clean the AI response after a human message
  function extractAiAnswer(humanEl) {
    // Walk up until we find a container whose NEXT SIBLING is the AI turn
    let node = humanEl;
    for (let i = 0; i < 10; i++) {
      if (!node.parentElement) break;
      const parent = node.parentElement;
      const siblings = Array.from(parent.children);
      const myIdx = siblings.indexOf(node);

      // Check if next sibling exists and contains no user-message (= AI turn)
      const next = siblings[myIdx + 1];
      if (next && !next.querySelector('[data-testid="user-message"]')) {
        const text = next.innerText || next.textContent || '';
        if (text.trim().length > 20) {
          const clone = next.cloneNode(true);
          return cleanAiHtml(clone);
        }
      }
      node = parent;
    }
    return null;
  }

  // Deep-clean a cloned AI response element for sharing
  function cleanAiHtml(root) {
    // 1. Remove all interactive / decorative elements
    const removeSelectors = [
      'button', '[role="button"]',
      // copy buttons, thumbs, regenerate, etc.
      'svg',
      // claude.ai toolbar rows
      '[data-testid="action-bar"]', '[data-testid="copy-button"]',
      '[class*="toolbar"]', '[class*="actions"]', '[class*="ActionBar"]',
      '[class*="feedback"]', '[class*="Feedback"]',
      '[class*="regenerate"]',
    ];
    removeSelectors.forEach(sel => {
      root.querySelectorAll(sel).forEach(el => el.remove());
    });

    // 2. Recursively rebuild clean HTML, preserving semantic tags and current state
    return rebuildClean(root);
  }

  // Allowed inline tags to preserve as-is (with cleaned attrs)
  const INLINE_TAGS = new Set(['strong','b','em','i','u','s','del','ins','mark','sub','sup','code','a','br','span']);
  // Allowed block tags
  const BLOCK_TAGS = new Set(['p','div','section','article','blockquote',
    'h1','h2','h3','h4','h5','h6',
    'ul','ol','li',
    'table','thead','tbody','tr','th','td',
    'pre','hr']);
  // Tags to unwrap (keep children, discard tag)
  const UNWRAP_TAGS = new Set(['figure','figcaption','header','footer','nav','aside','main']);

  function rebuildClean(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      return node.textContent
        .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return '';

    const tag = node.tagName.toLowerCase();

    // Skip entirely
    if (['script','style','noscript','button','input','select','textarea'].includes(tag)) return '';

    // Collect children
    const inner = Array.from(node.childNodes).map(rebuildClean).join('');

    // Preserve <pre><code> blocks as-is (already cleaned of buttons above)
    if (tag === 'pre') {
      const codeEl = node.querySelector('code');
      const lang = codeEl ? (codeEl.className.match(/language-(\w+)/) || [])[1] || '' : '';
      const codeText = codeEl
        ? codeEl.textContent.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
        : inner;
      const langLabel = lang ? `<div class="code-lang">${lang}</div>` : '';
      return `<pre>${langLabel}<code>${codeText}</code></pre>`;
    }

    // <a> — keep href, strip everything else
    if (tag === 'a') {
      const href = node.getAttribute('href') || '#';
      const isExternal = href.startsWith('http');
      return `<a href="${escapeHtml(href)}"${isExternal ? ' target="_blank" rel="noopener"' : ''}>${inner}</a>`;
    }

    // <img> — convert to alt text
    if (tag === 'img') {
      const alt = node.getAttribute('alt') || '';
      return alt ? `<em>[图片：${escapeHtml(alt)}]</em>` : '';
    }

    // Details/summary — respect current open state (snapshot)
    if (tag === 'details') {
      const isOpen = node.hasAttribute('open');
      if (!isOpen) return ''; // collapsed → skip entirely
      // open → render contents without the <details> wrapper
      const summary = node.querySelector('summary');
      const summaryText = summary ? summary.innerText || '' : '';
      const bodyNodes = Array.from(node.childNodes).filter(n => n !== summary);
      const bodyHtml = bodyNodes.map(rebuildClean).join('');
      return `<div class="details-open"><div class="details-summary">${escapeHtml(summaryText)}</div><div class="details-body">${bodyHtml}</div></div>`;
    }
    if (tag === 'summary') return ''; // handled above

    if (INLINE_TAGS.has(tag)) {
      if (tag === 'span') return inner; // unwrap spans (just carry text)
      return `<${tag}>${inner}</${tag}>`;
    }

    if (BLOCK_TAGS.has(tag)) {
      // table tags — keep structure
      if (['table','thead','tbody','tr','th','td'].includes(tag)) {
        return `<${tag}>${inner}</${tag}>`;
      }
      return `<${tag}>${inner}</${tag}>`;
    }

    if (UNWRAP_TAGS.has(tag)) return inner;

    // Everything else: unwrap and keep children
    return inner;
  }

  // ── Scrape human messages ─────────────────────────────────────────────────
  function getHumanMessages() {
    const results = [];
    const humanEls = document.querySelectorAll('[data-testid="user-message"]');
    if (humanEls.length > 0) {
      humanEls.forEach((el, idx) => {
        const text = extractText(el);
        if (text) results.push({ index: idx, text, el });
      });
      return results;
    }
    const classEls = document.querySelectorAll('.human-turn, [class*="HumanTurn"], [class*="human-turn"]');
    if (classEls.length > 0) {
      classEls.forEach((el, idx) => {
        const text = extractText(el);
        if (text) results.push({ index: idx, text, el });
      });
      return results;
    }
    const turns = document.querySelectorAll('[class*="ConversationItem"], [class*="conversation-item"]');
    turns.forEach((el, idx) => {
      const isHuman = el.querySelector('[class*="human"], [data-is-human]') !== null
        || el.classList.toString().toLowerCase().includes('human');
      if (isHuman) {
        const text = extractText(el);
        if (text) results.push({ index: idx, text, el });
      }
    });
    return results;
  }

  function extractText(el) {
    return (el.innerText || el.textContent || '').trim().replace(/\s+/g, ' ');
  }

  // ── Build timeline ────────────────────────────────────────────────────────
  function updateTimeline() {
    const countEl = document.getElementById('tl-count');
    if (!countEl) return;
    allHumanMessages = getHumanMessages();
    countEl.textContent = `${allHumanMessages.length} 条`;
    const searchInput = document.getElementById('tl-search');
    if (searchInput && searchInput.value) {
      applySearch();
    } else {
      renderItems(allHumanMessages);
    }
    addHighlightActiveOnScroll();
  }

  function renderItems(messages) {
    const list = document.getElementById('tl-list');
    if (!list) return;
    list.innerHTML = '';

    if (allHumanMessages.length === 0) {
      list.innerHTML = `<div class="tl-empty">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
        <p>未检测到提问内容<br><small>请确认当前页面有对话内容</small></p>
      </div>`;
      return;
    }

    if (messages.length === 0) {
      list.innerHTML = `<div class="tl-empty">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <p>没有找到相关提问</p>
      </div>`;
      return;
    }

    const fragment = document.createDocumentFragment();
    messages.forEach(msg => {
      const item = document.createElement('div');
      item.className = 'tl-item';
      if (shareMode && selectedTurns.has(msg.index)) item.classList.add('tl-selected');
      item.dataset.origIndex = msg.index;

      const preview = msg.text.length > 85 ? msg.text.slice(0, 85) + '…' : msg.text;
      const num = String(msg.index + 1).padStart(2, '0');

      item.innerHTML = `
        ${shareMode ? `<div class="tl-checkbox ${selectedTurns.has(msg.index) ? 'checked' : ''}" data-idx="${msg.index}">
          <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2"><polyline points="2,6 5,9 10,3"/></svg>
        </div>` : ''}
        <div class="tl-item-line"></div>
        <div class="tl-item-dot"></div>
        <div class="tl-item-body">
          <div class="tl-item-meta">
            <span class="tl-item-num">Q${num}</span>
          </div>
          <div class="tl-item-preview">${escapeHtml(preview)}</div>
        </div>
      `;

      item.addEventListener('click', () => {
        if (shareMode) {
          toggleTurnSelection(msg.index, item);
        } else {
          scrollToMessage(msg.el, item);
        }
      });
      fragment.appendChild(item);
    });

    list.appendChild(fragment);
  }

  function toggleTurnSelection(idx, itemEl) {
    if (selectedTurns.has(idx)) {
      selectedTurns.delete(idx);
      itemEl.classList.remove('tl-selected');
      const cb = itemEl.querySelector('.tl-checkbox');
      if (cb) cb.classList.remove('checked');
    } else {
      selectedTurns.add(idx);
      itemEl.classList.add('tl-selected');
      const cb = itemEl.querySelector('.tl-checkbox');
      if (cb) cb.classList.add('checked');
    }
    updateSelectedCount();
  }

  function escapeHtml(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // ── Search ────────────────────────────────────────────────────────────────
  function applySearch() {
    const query = (document.getElementById('tl-search')?.value || '').trim().toLowerCase();
    if (!query) { renderItems(allHumanMessages); return; }
    const filtered = allHumanMessages.filter(msg => msg.text.toLowerCase().includes(query));
    renderItems(filtered);
  }

  // ── Scroll to message ─────────────────────────────────────────────────────
  function scrollToMessage(el, itemEl) {
    if (!el) return;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    document.querySelectorAll('.tl-highlight-active').forEach(e => e.classList.remove('tl-highlight-active'));
    el.classList.add('tl-highlight-active');
    setTimeout(() => el.classList.remove('tl-highlight-active'), 2500);
    document.querySelectorAll('.tl-item').forEach(i => i.classList.remove('tl-active'));
    itemEl.classList.add('tl-active');
  }

  // ── Highlight active on scroll ────────────────────────────────────────────
  function addHighlightActiveOnScroll() {
    if (window._tlScrollHandler) window.removeEventListener('scroll', window._tlScrollHandler, true);
    window._tlScrollHandler = () => {
      if (!isVisible || shareMode) return;
      const mid = window.innerHeight / 2;
      let closest = null, closestDist = Infinity;
      allHumanMessages.forEach(msg => {
        if (!msg.el) return;
        const rect = msg.el.getBoundingClientRect();
        const dist = Math.abs(rect.top + rect.height / 2 - mid);
        if (dist < closestDist) { closestDist = dist; closest = msg.index; }
      });
      if (closest !== null) {
        document.querySelectorAll('.tl-item').forEach(el => {
          el.classList.toggle('tl-active', parseInt(el.dataset.origIndex) === closest);
        });
        if (!userScrollingPanel) {
          const active = document.querySelector('.tl-item.tl-active');
          if (active) active.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
        }
      }
    };
    window.addEventListener('scroll', window._tlScrollHandler, { passive: true, capture: true });
  }

  // ── MutationObserver ──────────────────────────────────────────────────────
  function observeConversation() {
    observer = new MutationObserver(() => {
      if (!isVisible) return;
      clearTimeout(updateTimer);
      updateTimer = setTimeout(updateTimeline, 700);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  // ── SPA navigation ────────────────────────────────────────────────────────
  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (shareMode) exitShareMode();
      setTimeout(() => { if (isVisible) updateTimeline(); }, 1200);
    }
  }).observe(document.body, { childList: true, subtree: true });

  // ── Start ─────────────────────────────────────────────────────────────────
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
